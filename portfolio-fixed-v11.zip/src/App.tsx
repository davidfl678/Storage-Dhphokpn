import { useState, useEffect } from 'react';
import { initialProfileData, videoItems as initialVideoItems } from './data/portfolioData';
import { ProfileData, VideoItem } from './types';
import { SnowCanvas } from './components/SnowCanvas';
import { AudioPlayer } from './components/AudioPlayer';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { VideoShowcase } from './components/VideoShowcase';
import { WebProjectsSection } from './components/WebProjectsSection';
import { SkillsAndAboutSection } from './components/SkillsAndAboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { QuickConfigModal } from './components/QuickConfigModal';
import { stripLocationHash } from './utils/scroll';
import { WelcomeGate } from './components/WelcomeGate';

export function App() {
  const [profileData, setProfileData] = useState<ProfileData>(() => {
    const saved = localStorage.getItem('thishan_profile_data');
    if (saved) {
      try {
        // Merge over defaults so newly added fields (e.g. songFallbackUrl)
        // are backfilled for visitors with older saved data
        return { ...initialProfileData, ...JSON.parse(saved) };
      } catch (e) {
        console.error("Failed to parse saved profile data", e);
      }
    }
    return initialProfileData;
  });

  const [videos, setVideos] = useState<VideoItem[]>(() => {
    const saved = localStorage.getItem('thishan_videos_data');
    if (saved) {
      try {
        const parsed: VideoItem[] = JSON.parse(saved);
        // Merge each saved video over its default so new fields (e.g. fallbackUrl)
        // are backfilled even when old data exists in localStorage
        return parsed.map((v) => ({
          ...initialVideoItems.find((d) => d.id === v.id),
          ...v,
        }));
      } catch (e) {
        console.error("Failed to parse saved video data", e);
      }
    }
    return initialVideoItems;
  });

  const [configModalOpen, setConfigModalOpen] = useState(false);

  // Clean #hash from URL on load (shared links still scroll, bar stays clean)
  useEffect(() => {
    stripLocationHash();
  }, []);

  useEffect(() => {
    localStorage.setItem('thishan_profile_data', JSON.stringify(profileData));
  }, [profileData]);

  useEffect(() => {
    localStorage.setItem('thishan_videos_data', JSON.stringify(videos));
  }, [videos]);

  const handleSaveProfile = (newData: ProfileData) => {
    setProfileData(newData);
  };

  const handleSaveVideos = (newVideos: VideoItem[]) => {
    setVideos(newVideos);
  };

  const handleResetDefaults = () => {
    setProfileData(initialProfileData);
    setVideos(initialVideoItems);
    localStorage.removeItem('thishan_profile_data');
    localStorage.removeItem('thishan_videos_data');
  };

  const handleUpdateWhatsApp = (index: number, newNumber: string) => {
    const updated = [...profileData.whatsappNumbers];
    if (updated[index]) {
      updated[index] = { ...updated[index], number: newNumber };
      setProfileData({ ...profileData, whatsappNumbers: updated });
    }
  };

  return (
    <div className="min-h-screen bg-[#070709] text-gray-100 relative selection:bg-red-600 selection:text-white">
      
      {/* ❄️ Falling Snow & Embers Particle Canvas */}
      <SnowCanvas initialMode="snow" />

      {/* Background Atmosphere Gradients */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[800px] bg-gradient-to-b from-red-600/10 via-rose-950/5 to-transparent blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-red-900/10 rounded-full blur-3xl" />
        <div className="absolute top-1/3 left-0 w-[400px] h-[400px] bg-rose-950/15 rounded-full blur-3xl" />
        <div className="absolute inset-0 bg-cyber-grid opacity-25" />
      </div>

      {/* Sticky Modern Top Header */}
      <Navbar
        onOpenConfig={() => setConfigModalOpen(true)}
        telegramUrl={profileData.telegram.url}
        whatsappPrimary={profileData.whatsappNumbers[0]?.link || ''}
      />

      {/* Main Portfolio Content */}
      <main className="relative z-10 flex flex-col">
        {/* Top Profile Hero Section with Backdrop Cover */}
        <HeroSection
          data={profileData}
          onOpenVideo={() => {
            const el = document.getElementById('videos');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Video Showcase Section (Anime Edit & AE Edit) */}
        <VideoShowcase videos={videos} />

        {/* Web Development Projects Section */}
        <WebProjectsSection />

        {/* Skills & Dual Expertise Matrix */}
        <SkillsAndAboutSection />

        {/* Contact Hub (Email, WhatsApp 3 Chats, Telegram) */}
        <ContactSection
          data={profileData}
          onUpdateWhatsApp={handleUpdateWhatsApp}
        />
      </main>

      {/* Footer with Dynamic Auto-updating Year & Social Icons */}
      <Footer data={profileData} />

      {/* Welcome Gate Popup (OK tap enables music autoplay) */}
      <WelcomeGate />

      {/* Floating Background Audio Player (Music & Equalizer) */}
      <AudioPlayer
        songUrl={profileData.songUrl}
        localUrl={profileData.songLocalUrl}
        proxyUrl={profileData.songProxyUrl}
        fallbackUrl={profileData.songFallbackUrl}
        songTitle={profileData.songTitle}
        songArtist={profileData.songArtist}
      />

      {/* Live Customization / Link Editor Modal */}
      <QuickConfigModal
        isOpen={configModalOpen}
        onClose={() => setConfigModalOpen(false)}
        profileData={profileData}
        videos={videos}
        onSaveProfile={handleSaveProfile}
        onSaveVideos={handleSaveVideos}
        onResetDefaults={handleResetDefaults}
      />

    </div>
  );
}

export default App;
