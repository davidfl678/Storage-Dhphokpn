// Hash-free in-page navigation — keeps the address bar clean (no #section in URL)
export const scrollToId = (id: string) => {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
};

export const scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

// If the page was opened with a #hash (shared link), scroll there once,
// then clean the URL so it looks like a plain static address
export const stripLocationHash = () => {
  if (!window.location.hash) return;
  const id = window.location.hash.slice(1);
  requestAnimationFrame(() => {
    if (id) document.getElementById(id)?.scrollIntoView();
    window.history.replaceState(null, '', window.location.pathname + window.location.search);
  });
};
