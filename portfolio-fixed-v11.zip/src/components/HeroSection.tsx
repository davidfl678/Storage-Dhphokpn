import React, { useState, useEffect } from 'react';
import { scrollToId } from '../utils/scroll';
import { 
  Sparkles, 
  Calendar, 
  MapPin, 
  CheckCircle2, 
  Play, 
  Copy, 
  Check, 
  ExternalLink,
  Code,
  Film,
  Flame,
  Clock,
  Send
} from 'lucide-react';
import { ProfileData } from '../types';

interface HeroSectionProps {
  data: ProfileData;
  onOpenVideo?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ data, onOpenVideo }) => {
  const [copied, setCopied] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [showLightbox, setShowLightbox] = useState(false);
  const [daysUntilBirthday, setDaysUntilBirthday] = useState<number>(0);

  // Calculate live age and countdown to next birthday (Sept 19)
  useEffect(() => {
    const today = new Date();
    const birthMonth = 8; // 0-indexed (8 = September)
    const birthDay = 19;

    let nextBday = new Date(today.getFullYear(), birthMonth, birthDay);
    if (today > nextBday) {
      nextBday = new Date(today.getFullYear() + 1, birthMonth, birthDay);
    }
    const diffTime = nextBday.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    setDaysUntilBirthday(diffDays);
  }, []);

  const handleCopyContact = () => {
    const info = `Name: ${data.name}\nRole: ${data.headline}\nAge: ${data.age} (DOB: 2008/09/19)\nEmail: ${data.email}\nTelegram: ${data.telegram.url}`;
    navigator.clipboard.writeText(info);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Fallback avatar if url has issues
  const fallbackAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80";

  return (
    <section className="relative pt-24 pb-16 md:pt-28 md:pb-24 overflow-hidden order-1">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[600px] bg-gradient-to-b from-red-600/15 via-rose-950/10 to-transparent blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Main Profile Showcase Card */}
        <div className="relative rounded-3xl bg-[#0c0c11]/80 border border-red-500/20 shadow-2xl overflow-hidden backdrop-blur-xl">
          
          {/* Backdrop Photo Banner */}
          <div className="relative h-48 sm:h-64 md:h-72 w-full overflow-hidden bg-neutral-900 group">
            <img
              src={data.backdropUrl}
              alt="Backdrop cover"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-90"
              onError={(e) => {
                // If local image fails, fallback to styled gradient
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            {/* Dark & Red Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c11] via-[#0c0c11]/60 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-red-950/30 via-transparent to-red-950/30" />
            
            {/* Subtle grid pattern */}
            <div className="absolute inset-0 bg-cyber-grid opacity-30" />

            {/* Backdrop Tag / Status top right */}
            <div className="absolute top-4 right-4 flex items-center gap-2">
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 border border-red-500/30 text-[11px] font-medium text-red-300 backdrop-blur-md shadow-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {data.status}
              </span>
            </div>

            {/* Backdrop badge bottom-right */}
            <div className="absolute bottom-4 right-4 hidden sm:flex items-center gap-2 text-xs font-mono text-gray-300 bg-black/50 backdrop-blur-md px-3 py-1 rounded-lg border border-white/10">
              <Sparkles className="w-3.5 h-3.5 text-red-400" />
              <span>Cyber Crimson UI</span>
            </div>
          </div>

          {/* Profile Header Details (Overlapping the banner) */}
          <div className="relative px-6 sm:px-10 pb-8 pt-0">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 -mt-20 sm:-mt-24 mb-6">
              
              {/* Profile Avatar & Ring */}
              <div className="flex flex-col sm:flex-row items-center sm:items-end gap-5">
                <div 
                  className="relative group cursor-pointer"
                  onClick={() => setShowLightbox(true)}
                  title="Click to view full photo"
                >
                  {/* Glowing Animated Outer Ring */}
                  <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-red-600 via-rose-500 to-red-900 opacity-75 blur-md group-hover:opacity-100 group-hover:blur-lg transition duration-500 animate-pulse" />
                  
                  {/* Avatar Container */}
                  <div className="relative w-32 h-32 sm:w-36 sm:h-36 md:w-40 md:h-40 rounded-full p-1.5 bg-[#0a0a0e] shadow-2xl">
                    <div className="w-full h-full rounded-full overflow-hidden border-2 border-red-500/60 bg-neutral-900 flex items-center justify-center">
                      <img
                        src={imageError ? fallbackAvatar : data.profilePicUrl}
                        alt={data.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        onError={() => setImageError(true)}
                      />
                    </div>
                  </div>

                  {/* Verified Badge Icon */}
                  <div className="absolute bottom-2 right-2 w-8 h-8 rounded-full bg-red-600 border-2 border-[#0c0c11] flex items-center justify-center text-white shadow-lg shadow-red-600/50" title="Verified Creator">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                </div>

                {/* Name & Main Titles */}
                <div className="text-center sm:text-left flex flex-col pt-2">
                  <div className="flex items-center justify-center sm:justify-start gap-2 mb-1">
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight font-display">
                      {data.name}
                    </h1>
                  </div>

                  <div className="inline-flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                    <span className="text-base sm:text-lg font-semibold text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-rose-300 to-red-500">
                      @{data.headline}
                    </span>
                  </div>

                  {/* Fast Badges */}
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-2">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-red-950/60 border border-red-500/30 text-red-300 text-xs font-mono">
                      <Code className="w-3 h-3 text-red-400" /> Web Dev
                    </span>
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs font-mono">
                      <Film className="w-3 h-3 text-rose-400" /> AE / AMV Editor
                    </span>
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-neutral-900 border border-white/10 text-gray-300 text-xs font-mono">
                      <MapPin className="w-3 h-3 text-red-400" /> {data.location}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons Right */}
              <div className="flex items-center justify-center gap-2.5 pt-2">
                <button
                  onClick={handleCopyContact}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 border border-white/10 text-xs font-medium text-gray-300 hover:text-white transition-all active:scale-95 shadow-md"
                  title="Copy Contact Summary"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-400">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-gray-400" />
                      <span>Copy Card</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => scrollToId('contact')}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-bold shadow-lg shadow-red-600/40 hover:shadow-red-600/60 transition-all active:scale-95"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Contact Me</span>
                </button>
              </div>
            </div>

            {/* Info Grid (Age, Birthday, Role, Experience) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-4 border-t border-red-500/15">
              
              {/* Card 1: Age */}
              <div className="glass-panel p-3.5 rounded-2xl border border-white/5 hover:border-red-500/30 transition-all flex items-center gap-3.5 group">
                <div className="w-10 h-10 rounded-xl bg-red-950/70 border border-red-500/30 flex items-center justify-center text-red-400 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-white transition-all">
                  <Flame className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] text-gray-400 font-mono uppercase tracking-wider">Age</span>
                  <span className="text-base font-bold text-white flex items-center gap-1">
                    {data.age} Years Old
                  </span>
                </div>
              </div>

              {/* Card 2: Birthday */}
              <div className="glass-panel p-3.5 rounded-2xl border border-white/5 hover:border-red-500/30 transition-all flex items-center gap-3.5 group">
                <div className="w-10 h-10 rounded-xl bg-red-950/70 border border-red-500/30 flex items-center justify-center text-red-400 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-white transition-all">
                  <Calendar className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] text-gray-400 font-mono uppercase tracking-wider">Birthday</span>
                  <span className="text-base font-bold text-white">
                    2008 / 09 / 19
                  </span>
                </div>
              </div>

              {/* Card 3: Specialty */}
              <div className="glass-panel p-3.5 rounded-2xl border border-white/5 hover:border-red-500/30 transition-all flex items-center gap-3.5 group">
                <div className="w-10 h-10 rounded-xl bg-red-950/70 border border-red-500/30 flex items-center justify-center text-red-400 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-white transition-all">
                  <Film className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] text-gray-400 font-mono uppercase tracking-wider">AE / VFX Editing</span>
                  <span className="text-sm font-bold text-gray-200">
                    After Effects & AMV
                  </span>
                </div>
              </div>

              {/* Card 4: Birthday Countdown */}
              <div className="glass-panel p-3.5 rounded-2xl border border-white/5 hover:border-red-500/30 transition-all flex items-center gap-3.5 group">
                <div className="w-10 h-10 rounded-xl bg-red-950/70 border border-red-500/30 flex items-center justify-center text-red-400 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-white transition-all">
                  <Clock className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] text-gray-400 font-mono uppercase tracking-wider">Next Birthday</span>
                  <span className="text-sm font-bold text-red-400">
                    {daysUntilBirthday === 0 ? "🎉 Today is Birthday!" : `In ${daysUntilBirthday} days 🎂`}
                  </span>
                </div>
              </div>

            </div>

            {/* Bio summary description */}
            <div className="mt-5 p-4 rounded-2xl bg-black/40 border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-2xl">
                {data.bio}
              </p>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  type="button"
                  onClick={onOpenVideo}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-600/20 hover:bg-red-600/30 border border-red-500/40 text-red-300 hover:text-white text-xs font-semibold transition-all"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Watch 2 Edits</span>
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* Lightbox Modal for Profile Image */}
      {showLightbox && (
        <div 
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setShowLightbox(false)}
        >
          <div className="relative max-w-md w-full glass-panel-red p-4 rounded-3xl border border-red-500/40 shadow-2xl flex flex-col items-center">
            <div className="w-64 h-64 sm:w-72 sm:h-72 rounded-2xl overflow-hidden border-2 border-red-500 shadow-xl mb-4">
              <img
                src={imageError ? fallbackAvatar : data.profilePicUrl}
                alt={data.name}
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="text-xl font-bold text-white mb-1">{data.name}</h3>
            <p className="text-xs text-red-400 mb-4 font-mono">@{data.headline}</p>
            <div className="flex gap-2">
              <a
                href={data.profilePicUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-neutral-900 border border-white/10 text-xs text-gray-300 hover:text-white"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open Original Image</span>
              </a>
              <button
                onClick={() => setShowLightbox(false)}
                className="px-4 py-1.5 rounded-xl bg-red-600 text-white text-xs font-semibold hover:bg-red-500"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
