import React, { useEffect, useRef, useState } from 'react';
import { Snowflake, Eye, EyeOff, Sparkles, Sliders } from 'lucide-react';

interface Particle {
  x: number;
  y: number;
  radius: number;
  density: number;
  speedY: number;
  speedX: number;
  opacity: number;
  rotation: number;
  rotationSpeed: number;
  colorType: 'white' | 'red' | 'sparkle';
  flakeArms?: number;
}

export type ParticleMode = 'snow' | 'crimson-embers' | 'blizzard';

interface SnowCanvasProps {
  initialMode?: ParticleMode;
}

export const SnowCanvas: React.FC<SnowCanvasProps> = ({ initialMode = 'snow' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [mode, setMode] = useState<ParticleMode>(initialMode);
  const [isEnabled, setIsEnabled] = useState<boolean>(true);
  const [particleCount, setParticleCount] = useState<number>(75);
  const [showControls, setShowControls] = useState<boolean>(false);
  const mousePos = useRef<{ x: number; y: number }>({ x: -1000, y: -1000 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !isEnabled) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const handleMouseMove = (e: MouseEvent) => {
      mousePos.current = { x: e.clientX, y: e.clientY };
    };
    window.addEventListener('mousemove', handleMouseMove);

    // Initialize particles
    const particles: Particle[] = [];
    const count = mode === 'blizzard' ? particleCount * 2 : particleCount;

    for (let i = 0; i < count; i++) {
      particles.push(createParticle(width, height, mode, true));
    }

    function createParticle(w: number, h: number, currentMode: ParticleMode, randomY = false): Particle {
      const radius = currentMode === 'crimson-embers' 
        ? Math.random() * 2.5 + 1 
        : Math.random() * 3 + 1.2;

      let colorType: 'white' | 'red' | 'sparkle' = 'white';
      if (currentMode === 'crimson-embers') {
        colorType = Math.random() > 0.3 ? 'red' : 'sparkle';
      } else {
        colorType = Math.random() > 0.85 ? 'red' : 'white';
      }

      return {
        x: Math.random() * w,
        y: randomY ? Math.random() * h : -10,
        radius,
        density: Math.random() * 20 + 10,
        speedY: currentMode === 'blizzard' 
          ? Math.random() * 2.8 + 1.8 
          : currentMode === 'crimson-embers'
            ? Math.random() * 1.5 + 0.6
            : Math.random() * 1.6 + 0.7,
        speedX: (Math.random() - 0.5) * (currentMode === 'blizzard' ? 2 : 0.8),
        opacity: Math.random() * 0.7 + 0.3,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.02,
        colorType,
        flakeArms: Math.floor(Math.random() * 3) + 4
      };
    }

    function drawSnowflake(ctx: CanvasRenderingContext2D, p: Particle) {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);

      if (p.colorType === 'red') {
        ctx.fillStyle = `rgba(239, 68, 68, ${p.opacity * 0.9})`;
        ctx.shadowColor = 'rgba(239, 68, 68, 0.8)';
        ctx.shadowBlur = 8;
      } else if (p.colorType === 'sparkle') {
        ctx.fillStyle = `rgba(255, 180, 200, ${p.opacity})`;
        ctx.shadowColor = 'rgba(255, 100, 150, 0.6)';
        ctx.shadowBlur = 6;
      } else {
        ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity * 0.85})`;
        ctx.shadowColor = 'rgba(255, 255, 255, 0.4)';
        ctx.shadowBlur = 4;
      }

      // If particle is larger, draw a distinct snowflake or soft glow orb
      if (p.radius > 2.2 && mode !== 'crimson-embers') {
        ctx.strokeStyle = p.colorType === 'red' ? `rgba(239, 68, 68, ${p.opacity})` : `rgba(255, 255, 255, ${p.opacity})`;
        ctx.lineWidth = 1;
        const arms = p.flakeArms || 6;
        for (let a = 0; a < arms; a++) {
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(0, p.radius * 1.8);
          ctx.stroke();
          ctx.rotate((Math.PI * 2) / arms);
        }
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }

    let angle = 0;
    const render = () => {
      ctx.clearRect(0, 0, width, height);
      angle += 0.01;

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Sway motion
        p.rotation += p.rotationSpeed;
        p.y += p.speedY;
        p.x += Math.sin(angle + p.density) * 0.5 + p.speedX;

        // Subtle mouse repulsion
        const dx = mousePos.current.x - p.x;
        const dy = mousePos.current.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          const force = (100 - dist) / 100;
          p.x -= (dx / dist) * force * 2;
          p.y -= (dy / dist) * force * 2;
        }

        // Draw particle
        drawSnowflake(ctx, p);

        // Reset if reached bottom or went off-screen
        if (p.y > height + 10 || p.x < -20 || p.x > width + 20) {
          particles[i] = createParticle(width, height, mode, false);
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [mode, isEnabled, particleCount]);

  return (
    <>
      {isEnabled && (
        <canvas
          ref={canvasRef}
          className="fixed inset-0 pointer-events-none z-30"
          style={{ mixBlendMode: 'screen' }}
          aria-hidden="true"
        />
      )}

      {/* Floating Snow Effect Controller Pill (bottom-right above footer) */}
      <div className="fixed bottom-24 right-5 z-40 flex flex-col items-end gap-2">
        {showControls && (
          <div className="glass-panel-red p-3 rounded-2xl shadow-2xl border border-red-500/30 text-xs text-gray-200 flex flex-col gap-2.5 animate-fadeIn backdrop-blur-xl w-48">
            <div className="flex items-center justify-between pb-1.5 border-b border-red-500/20">
              <span className="font-semibold text-red-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Snow FX Setting
              </span>
              <button
                onClick={() => setIsEnabled(!isEnabled)}
                className={`p-1 rounded-md transition-colors ${
                  isEnabled ? 'bg-red-500/20 text-red-300' : 'bg-gray-800 text-gray-400'
                }`}
                title={isEnabled ? "Disable Snow" : "Enable Snow"}
              >
                {isEnabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>
            </div>

            {isEnabled && (
              <>
                <div className="flex flex-col gap-1">
                  <span className="text-[11px] text-gray-400">Particle Mode</span>
                  <div className="grid grid-cols-3 gap-1">
                    <button
                      onClick={() => setMode('snow')}
                      className={`px-1.5 py-1 rounded text-[10px] font-medium transition-all ${
                        mode === 'snow'
                          ? 'bg-red-600 text-white shadow-sm'
                          : 'bg-black/40 text-gray-300 hover:bg-red-950/40'
                      }`}
                    >
                      ❄️ Snow
                    </button>
                    <button
                      onClick={() => setMode('crimson-embers')}
                      className={`px-1.5 py-1 rounded text-[10px] font-medium transition-all ${
                        mode === 'crimson-embers'
                          ? 'bg-red-600 text-white shadow-sm'
                          : 'bg-black/40 text-gray-300 hover:bg-red-950/40'
                      }`}
                    >
                      🔥 Embers
                    </button>
                    <button
                      onClick={() => setMode('blizzard')}
                      className={`px-1.5 py-1 rounded text-[10px] font-medium transition-all ${
                        mode === 'blizzard'
                          ? 'bg-red-600 text-white shadow-sm'
                          : 'bg-black/40 text-gray-300 hover:bg-red-950/40'
                      }`}
                    >
                      🌨️ Storm
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <div className="flex justify-between text-[10px] text-gray-400">
                    <span>Intensity</span>
                    <span>{particleCount}</span>
                  </div>
                  <input
                    type="range"
                    min="30"
                    max="150"
                    step="10"
                    value={particleCount}
                    onChange={(e) => setParticleCount(Number(e.target.value))}
                    className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-500"
                  />
                </div>
              </>
            )}
          </div>
        )}

        <button
          onClick={() => setShowControls(!showControls)}
          className="group relative flex items-center gap-2 px-3.5 py-2 rounded-full glass-panel-red border border-red-500/40 hover:border-red-400 text-white text-xs font-medium shadow-lg hover:shadow-red-900/40 transition-all active:scale-95 cursor-pointer backdrop-blur-xl"
          title="Configure Falling Snow Effect"
        >
          <div className="relative">
            <Snowflake className={`w-4 h-4 text-red-400 ${isEnabled ? 'animate-spin' : ''}`} style={{ animationDuration: '8s' }} />
            {isEnabled && (
              <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-red-400 rounded-full animate-ping" />
            )}
          </div>
          <span className="hidden sm:inline text-gray-200">Snow FX</span>
          <Sliders className="w-3.5 h-3.5 text-gray-400 group-hover:text-red-400 transition-colors" />
        </button>
      </div>
    </>
  );
};
