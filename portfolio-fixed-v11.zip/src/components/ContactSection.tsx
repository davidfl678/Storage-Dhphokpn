import React, { useState } from 'react';
import { 
  Mail, 
  MessageSquare, 
  Send, 
  Copy, 
  Check, 
  ExternalLink, 
  Sparkles, 
  PhoneCall, 
  CheckCircle, 
  ArrowRight,
  ShieldCheck,
  QrCode
} from 'lucide-react';
import { ProfileData } from '../types';

interface ContactSectionProps {
  data: ProfileData;
  onUpdateWhatsApp?: (index: number, newNumber: string) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ data }) => {
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [showQR, setShowQR] = useState(false);

  // Contact Form State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    service: 'Web Development',
    message: ''
  });
  const [formSentSuccess, setFormSentSuccess] = useState(false);

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2500);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.message) return;

    // Compose mailto or whatsapp trigger
    const subject = encodeURIComponent(`Portfolio Inquiry from ${formData.name} - [${formData.service}]`);
    const body = encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\nService: ${formData.service}\n\nMessage:\n${formData.message}`
    );

    // Open mail client
    window.open(`mailto:${data.email}?subject=${subject}&body=${body}`, '_blank');
    setFormSentSuccess(true);
    setTimeout(() => setFormSentSuccess(false), 5000);
  };

  const handleSendToWhatsApp = () => {
    if (!formData.name || !formData.message) return;
    const primaryLink =
      data.whatsappNumbers.find((n) => n.isPrimary)?.link ||
      data.whatsappNumbers[0]?.link ||
      '';
    if (primaryLink) window.open(primaryLink, '_blank');
  };

  return (
    <section id="contact" className="py-20 relative order-2 md:order-5">
      {/* Background radial accent */}
      <div className="absolute top-1/2 right-10 -translate-y-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/60 border border-red-500/30 text-red-400 text-xs font-mono uppercase tracking-wider mb-3">
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Direct Channels</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white font-display tracking-tight">
            Get In <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-red-600">Touch</span>
          </h2>
          <p className="text-sm sm:text-base text-gray-400 mt-2">
            Reach out directly through Proton Mail, WhatsApp, or Telegram for web development projects and video editing commissions.
          </p>
        </div>

        {/* 3 Core Contact Cards with Platform Icons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          
          {/* 1. EMAIL CARD */}
          <div className="group rounded-3xl bg-[#0c0c11]/90 border border-red-500/20 hover:border-red-500/50 p-6 flex flex-col justify-between shadow-2xl backdrop-blur-xl transition-all duration-300 hover:shadow-red-950/40">
            <div>
              {/* Platform Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-red-600 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-red-600/30 group-hover:scale-110 transition-transform">
                  <Mail className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full bg-red-950/60 border border-red-500/30 text-[10px] font-mono text-red-300">
                  Encrypted Proton
                </span>
              </div>

              <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">Email Address</span>
              <h3 className="text-lg font-bold text-white mt-1 break-all flex items-center gap-2">
                {data.email}
              </h3>
              <p className="text-xs text-gray-400 mt-2">
                Best for official inquiries, formal proposals, and detailed project briefs.
              </p>
            </div>

            <div className="pt-6 mt-6 border-t border-white/5 flex items-center gap-2">
              <button
                onClick={() => handleCopy(data.email, 'email')}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-white/10 text-xs font-semibold text-gray-200 hover:text-white transition-all active:scale-95"
              >
                {copiedType === 'email' ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-gray-400" />
                    <span>Copy Email</span>
                  </>
                )}
              </button>

              <a
                href={`mailto:${data.email}?subject=Collaboration%20Inquiry`}
                className="flex items-center justify-center px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-md shadow-red-600/30 active:scale-95"
                title="Open Mail Client"
              >
                <Send className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* 2. WHATSAPP CARD (With 3 Numbers Support) */}
          <div className="group rounded-3xl bg-[#0c0c11]/90 border border-emerald-500/20 hover:border-emerald-500/50 p-6 flex flex-col justify-between shadow-2xl backdrop-blur-xl transition-all duration-300 hover:shadow-emerald-950/40">
            <div>
              {/* Platform Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-green-500 flex items-center justify-center text-white shadow-lg shadow-emerald-600/30 group-hover:scale-110 transition-transform">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-[10px] font-mono text-emerald-300">
                  3 Chats Available
                </span>
              </div>

              <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">WhatsApp Chats</span>
              <h3 className="text-lg font-bold text-white mt-1">
                WhatsApp Direct Chat
              </h3>

              {/* 3 WhatsApp Link Buttons */}
              <div className="mt-3 flex flex-col gap-2">
                {data.whatsappNumbers.map((numItem, idx) => (
                  <a
                    key={idx}
                    href={numItem.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between gap-2 p-3 rounded-xl border bg-emerald-950/40 border-emerald-500/50 hover:bg-emerald-900/50 hover:border-emerald-400 transition-all active:scale-[0.98]"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                        <span className="text-sm font-bold text-white">{numItem.label}</span>
                        {numItem.isPrimary && (
                          <span className="text-[9px] bg-emerald-600/30 text-emerald-300 px-1.5 py-0.5 rounded font-mono">
                            Primary
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-gray-400 mt-0.5 truncate">{numItem.description}</p>
                    </div>
                    <span className="flex-shrink-0 w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-md shadow-emerald-600/30">
                      <ExternalLink className="w-4 h-4" />
                    </span>
                  </a>
                ))}
              </div>
            </div>
          </div>

                    {/* 3. TELEGRAM CARD */}
          <div className="group rounded-3xl bg-[#0c0c11]/90 border border-sky-500/20 hover:border-sky-500/50 p-6 flex flex-col justify-between shadow-2xl backdrop-blur-xl transition-all duration-300 hover:shadow-sky-950/40">
            <div>
              {/* Platform Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-sky-600/30 group-hover:scale-110 transition-transform">
                  <Send className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full bg-sky-950/60 border border-sky-500/30 text-[10px] font-mono text-sky-300">
                  Instant Response
                </span>
              </div>

              <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">Telegram Channel</span>
              <h3 className="text-lg font-bold text-white mt-1 flex items-center gap-1.5">
                {data.telegram.handle}
              </h3>
              <p className="text-xs text-gray-400 mt-2">
                Fastest way to get in touch for rapid questions, media file transfers, and quick quotes.
              </p>
            </div>

            <div className="pt-6 mt-6 border-t border-white/5 flex items-center gap-2">
              <button
                onClick={() => handleCopy(data.telegram.url, 'telegram')}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-white/10 text-xs font-semibold text-gray-200 hover:text-white transition-all active:scale-95"
              >
                {copiedType === 'telegram' ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-gray-400" />
                    <span>Copy Link</span>
                  </>
                )}
              </button>

              <a
                href={data.telegram.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center px-4 py-2.5 rounded-xl bg-[#229ED9] hover:bg-sky-400 text-white text-xs font-bold transition-all shadow-md shadow-sky-600/30 active:scale-95 gap-1.5"
                title="Open Telegram"
              >
                <span>Open</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

        </div>

        {/* Personal Description */}
        <div className="mb-12 rounded-3xl bg-[#0c0c11]/90 border border-red-500/20 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-red-600 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-red-600/30 flex-shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white">Description</h3>
          </div>
          <p className="text-sm sm:text-base text-gray-300 leading-relaxed">
            Hi, Thishan Dinujaya, 18 years old, junior web dev, first learned python at the age of 13, and in the meantime, I am also learning video editing.
          </p>
        </div>

        {/* Message Composer & QR Code Side-by-Side */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Quick Contact Form (2 Cols) */}
          <div className="lg:col-span-2 rounded-3xl bg-[#0c0c11]/80 border border-red-500/20 p-6 sm:p-8 backdrop-blur-xl">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-red-500" />
              <h3 className="text-xl font-bold text-white">Send Direct Message</h3>
            </div>
            <p className="text-xs sm:text-sm text-gray-400 mb-6">
              Fill in your details below to instantly dispatch a formatted brief to Thishan.
            </p>

            {formSentSuccess && (
              <div className="mb-6 p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
                <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Message composer triggered successfully! Check your mail app or WhatsApp window.</span>
              </div>
            )}

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="John Doe"
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900/90 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:border-red-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
                    Your Email or Phone
                  </label>
                  <input
                    type="text"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="john@example.com / WhatsApp"
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900/90 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:border-red-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
                  Service / Project Type
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    'Web Development',
                    'Anime AMV Edit',
                    'After Effects AE',
                    'Other / General'
                  ].map((srv) => (
                    <button
                      type="button"
                      key={srv}
                      onClick={() => setFormData({ ...formData, service: srv })}
                      className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all text-center ${
                        formData.service === srv
                          ? 'bg-red-600 text-white border border-red-500 shadow-md shadow-red-600/30'
                          : 'bg-neutral-900 border border-white/5 text-gray-400 hover:text-white'
                      }`}
                    >
                      {srv}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
                  Project Details / Message
                </label>
                <textarea
                  rows={4}
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell me about your project, timeline, and vision..."
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900/90 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:border-red-500 transition-colors resize-none"
                />
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <button
                  type="submit"
                  className="w-full sm:flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-red-600/40 transition-all active:scale-95"
                >
                  <Mail className="w-4 h-4" />
                  <span>Send via Email Client</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={handleSendToWhatsApp}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Send via WhatsApp</span>
                </button>
              </div>
            </form>
          </div>

          {/* Digital vCard & Quick QR Scanner (1 Col) */}
          <div className="rounded-3xl glass-panel-red p-6 sm:p-8 border border-red-500/30 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-red-400" />
                  <span className="text-xs font-mono text-red-300 uppercase tracking-wider">
                    Instant Connect
                  </span>
                </div>
                <button
                  onClick={() => setShowQR(!showQR)}
                  className="p-1.5 rounded-lg bg-neutral-900 text-gray-300 hover:text-white border border-white/10"
                  title="Toggle QR Code"
                >
                  <QrCode className="w-4 h-4" />
                </button>
              </div>

              <h4 className="text-lg font-bold text-white mb-2">Thishan Dinujaya</h4>
              <p className="text-xs text-red-400 font-mono mb-4">@ Web Dev & Video Editor</p>

              {/* QR Code Container */}
              <div className="p-4 rounded-2xl bg-white text-black flex flex-col items-center justify-center text-center shadow-2xl mb-4">
                {/* SVG QR Code Simulation */}
                <div className="w-36 h-36 bg-black p-2 rounded-xl flex items-center justify-center">
                  <div className="w-full h-full bg-white rounded-lg p-1.5 flex flex-col justify-between">
                    <div className="flex justify-between">
                      <div className="w-6 h-6 border-4 border-black bg-white rounded-sm" />
                      <div className="w-6 h-6 border-4 border-black bg-white rounded-sm" />
                    </div>
                    <div className="text-[10px] font-black text-center text-red-600 font-mono">
                      TD • DEV
                    </div>
                    <div className="flex justify-between">
                      <div className="w-6 h-6 border-4 border-black bg-white rounded-sm" />
                      <div className="w-3 h-3 bg-red-600 rounded-full" />
                    </div>
                  </div>
                </div>
                <span className="text-[11px] font-mono text-gray-700 mt-2 font-medium">
                  Scan to save vCard / Links
                </span>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-red-500/20 text-xs text-gray-300">
              <div className="flex justify-between">
                <span className="text-gray-400">Response Time:</span>
                <span className="text-emerald-400 font-semibold">&lt; 1 Hour</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Timezone:</span>
                <span className="text-white font-mono">GMT+5:30 (SL)</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
