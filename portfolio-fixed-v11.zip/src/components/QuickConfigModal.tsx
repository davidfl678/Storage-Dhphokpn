import React, { useState } from 'react';
import { 
  Settings2, 
  X, 
  Image, 
  Music, 
  Film, 
  MessageSquare, 
  Send, 
  Mail, 
  Check, 
  Save, 
  RotateCcw
} from 'lucide-react';
import { ProfileData, VideoItem } from '../types';

interface QuickConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  profileData: ProfileData;
  videos: VideoItem[];
  onSaveProfile: (newData: ProfileData) => void;
  onSaveVideos: (newVideos: VideoItem[]) => void;
  onResetDefaults: () => void;
}

export const QuickConfigModal: React.FC<QuickConfigModalProps> = ({
  isOpen,
  onClose,
  profileData,
  videos,
  onSaveProfile,
  onSaveVideos,
  onResetDefaults
}) => {
  const [localProfile, setLocalProfile] = useState<ProfileData>(profileData);
  const [localVideos, setLocalVideos] = useState<VideoItem[]>(videos);
  const [savedSuccess, setSavedSuccess] = useState(false);

  React.useEffect(() => {
    setLocalProfile(profileData);
    setLocalVideos(videos);
  }, [profileData, videos, isOpen]);

  if (!isOpen) return null;

  const handleSaveAll = () => {
    onSaveProfile(localProfile);
    onSaveVideos(localVideos);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleWhatsAppChange = (index: number, newNumber: string) => {
    const updated = [...localProfile.whatsappNumbers];
    if (updated[index]) {
      updated[index] = { ...updated[index], number: newNumber };
      setLocalProfile({ ...localProfile, whatsappNumbers: updated });
    }
  };

  const handleWhatsAppLinkChange = (index: number, newLink: string) => {
    const updated = [...localProfile.whatsappNumbers];
    if (updated[index]) {
      updated[index] = { ...updated[index], link: newLink };
      setLocalProfile({ ...localProfile, whatsappNumbers: updated });
    }
  };

  const handleVideoUrlChange = (index: number, newUrl: string) => {
    const updated = [...localVideos];
    if (updated[index]) {
      updated[index] = { ...updated[index], videoUrl: newUrl };
      setLocalVideos(updated);
    }
  };

  const handleVideoFallbackChange = (index: number, newUrl: string) => {
    const updated = [...localVideos];
    if (updated[index]) {
      updated[index] = { ...updated[index], fallbackUrl: newUrl };
      setLocalVideos(updated);
    }
  };

  const handleVideoProxyChange = (index: number, newUrl: string) => {
    const updated = [...localVideos];
    if (updated[index]) {
      updated[index] = { ...updated[index], proxyUrl: newUrl };
      setLocalVideos(updated);
    }
  };

  const handleVideoLocalChange = (index: number, newUrl: string) => {
    const updated = [...localVideos];
    if (updated[index]) {
      updated[index] = { ...updated[index], localUrl: newUrl };
      setLocalVideos(updated);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-fadeIn overflow-y-auto"
      onClick={onClose}
    >
      <div 
        className="relative max-w-2xl w-full rounded-3xl bg-[#0d0d12] border border-red-500/40 p-6 sm:p-8 shadow-2xl my-8 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-red-500/20 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <Settings2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Live Link & Asset Config</h3>
              <p className="text-xs text-gray-400">Update image URLs, songs, numbers & videos directly</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-900 text-gray-400 hover:text-white border border-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {savedSuccess && (
          <div className="mb-6 p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>Settings updated successfully!</span>
          </div>
        )}

        <div className="space-y-6 text-xs">
          
          {/* Section: Images & Media */}
          <div className="space-y-3">
            <span className="font-mono text-red-400 uppercase tracking-wider flex items-center gap-1.5 font-semibold">
              <Image className="w-3.5 h-3.5" /> Profile & Backdrop URLs
            </span>

            <div className="space-y-1.5">
              <label className="text-gray-300 font-medium">Profile Picture URL</label>
              <input
                type="text"
                value={localProfile.profilePicUrl}
                onChange={(e) => setLocalProfile({ ...localProfile, profilePicUrl: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                placeholder="https://..."
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-gray-300 font-medium">Backdrop Banner Photo URL</label>
              <input
                type="text"
                value={localProfile.backdropUrl}
                onChange={(e) => setLocalProfile({ ...localProfile, backdropUrl: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                placeholder="/images/backdrop.jpg or https://..."
              />
            </div>
          </div>

          {/* Section: Background Music */}
          <div className="space-y-3 pt-3 border-t border-white/5">
            <span className="font-mono text-red-400 uppercase tracking-wider flex items-center gap-1.5 font-semibold">
              <Music className="w-3.5 h-3.5" /> Background Audio
            </span>

            <div className="space-y-1.5">
              <label className="text-gray-300 font-medium">Background Song URL (spoo.me primary)</label>
              <input
                type="text"
                value={localProfile.songUrl}
                onChange={(e) => setLocalProfile({ ...localProfile, songUrl: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                placeholder="https://..."
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-gray-300 font-medium">Song Bundled URL <span className="text-gray-500">(site file, always works — tried 2nd)</span></label>
              <input
                type="text"
                value={localProfile.songLocalUrl || ''}
                onChange={(e) => setLocalProfile({ ...localProfile, songLocalUrl: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                placeholder="/audio/song.mp3"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-gray-300 font-medium">Song Proxy URL <span className="text-gray-500">(same-origin /media/…, tried 3rd)</span></label>
              <input
                type="text"
                value={localProfile.songProxyUrl || ''}
                onChange={(e) => setLocalProfile({ ...localProfile, songProxyUrl: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                placeholder="/media/song.mp3"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-gray-300 font-medium">Song Fallback URL <span className="text-gray-500">(direct CDN, last resort)</span></label>
              <input
                type="text"
                value={localProfile.songFallbackUrl || ''}
                onChange={(e) => setLocalProfile({ ...localProfile, songFallbackUrl: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                placeholder="https://... direct mp3"
              />
            </div>
          </div>

          {/* Section: Videos */}
          <div className="space-y-3 pt-3 border-t border-white/5">
            <span className="font-mono text-red-400 uppercase tracking-wider flex items-center gap-1.5 font-semibold">
              <Film className="w-3.5 h-3.5" /> Video Showcase URLs (Anime & AE)
            </span>

            {localVideos.map((vid, idx) => (
              <div key={vid.id} className="space-y-1.5 p-3 rounded-xl bg-neutral-900/50 border border-white/5">
                <label className="text-gray-300 font-medium flex items-center justify-between">
                  <span>{vid.title}</span>
                  <span className="text-[10px] text-red-400 font-mono">Video #{idx + 1}</span>
                </label>
                <input
                  type="text"
                  value={vid.videoUrl}
                  onChange={(e) => handleVideoUrlChange(idx, e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-black border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                  placeholder="https://... (spoo.me primary)"
                />
                <label className="text-[11px] text-gray-400 font-medium">
                  Bundled URL <span className="text-gray-600">(site file, always works — tried 2nd)</span>
                </label>
                <input
                  type="text"
                  value={vid.localUrl || ''}
                  onChange={(e) => handleVideoLocalChange(idx, e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-black border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                  placeholder="/videos/....mp4"
                />
                <label className="text-[11px] text-gray-400 font-medium">
                  Proxy URL <span className="text-gray-600">(same-origin /media/…, tried 3rd)</span>
                </label>
                <input
                  type="text"
                  value={vid.proxyUrl || ''}
                  onChange={(e) => handleVideoProxyChange(idx, e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-black border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                  placeholder="/media/....mp4"
                />
                <label className="text-[11px] text-gray-400 font-medium">
                  Fallback URL <span className="text-gray-600">(direct CDN, last resort)</span>
                </label>
                <input
                  type="text"
                  value={vid.fallbackUrl || ''}
                  onChange={(e) => handleVideoFallbackChange(idx, e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-black border border-white/10 text-white font-mono text-xs focus:border-red-500 outline-none"
                  placeholder="https://... direct mp4"
                />
              </div>
            ))}
          </div>

          {/* Section: WhatsApp & Contact */}
          <div className="space-y-3 pt-3 border-t border-white/5">
            <span className="font-mono text-red-400 uppercase tracking-wider flex items-center gap-1.5 font-semibold">
              <MessageSquare className="w-3.5 h-3.5" /> 3 WhatsApp Numbers & Contact Info
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {localProfile.whatsappNumbers.map((numItem, idx) => (
                <div key={idx} className="space-y-1">
                  <label className="text-[11px] text-gray-400">{numItem.label}</label>
                  <input
                    type="text"
                    value={numItem.number}
                    onChange={(e) => handleWhatsAppChange(idx, e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-emerald-500 outline-none"
                    placeholder="+94 7X XXX XXXX"
                  />
                  <input
                    type="text"
                    value={numItem.link || ''}
                    onChange={(e) => handleWhatsAppLinkChange(idx, e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-emerald-500 outline-none"
                    placeholder="https://spoo.me/..."
                  />
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-gray-300 font-medium flex items-center gap-1">
                  <Send className="w-3 h-3 text-sky-400" /> Telegram URL
                </label>
                <input
                  type="text"
                  value={localProfile.telegram.url}
                  onChange={(e) => setLocalProfile({ 
                    ...localProfile, 
                    telegram: { ...localProfile.telegram, url: e.target.value } 
                  })}
                  className="w-full px-3 py-1.5 rounded-xl bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-sky-500 outline-none"
                  placeholder="https://t.me/..."
                />
              </div>

              <div className="space-y-1">
                <label className="text-gray-300 font-medium flex items-center gap-1">
                  <Mail className="w-3 h-3 text-rose-400" /> Email Address
                </label>
                <input
                  type="text"
                  value={localProfile.email}
                  onChange={(e) => setLocalProfile({ ...localProfile, email: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-xl bg-neutral-900 border border-white/10 text-white font-mono text-xs focus:border-rose-500 outline-none"
                  placeholder="thishan-D@proton.me"
                />
              </div>
            </div>
          </div>

        </div>

        {/* Footer buttons */}
        <div className="pt-6 mt-6 border-t border-red-500/20 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => {
              onResetDefaults();
              onClose();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-gray-400 hover:text-white text-xs border border-white/10"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-gray-300 text-xs border border-white/10"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveAll}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-lg shadow-red-600/30"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Apply Changes</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
