import React from 'react';
import { scrollToId } from '../utils/scroll';
import { 
  Send, 
  Mail, 
  MessageSquare, 
  ArrowUp, 
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { ProfileData } from '../types';

interface FooterProps {
  data: ProfileData;
}

export const Footer: React.FC<FooterProps> = ({ data }) => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderSocialIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'telegram':
        return <Send className="w-4 h-4 text-sky-400" />;
      case 'email':
        return <Mail className="w-4 h-4 text-rose-400" />;
      case 'whatsapp':
        return <MessageSquare className="w-4 h-4 text-emerald-400" />;
      case 'github':
        return (
          <svg className="w-4 h-4 fill-current text-white" viewBox="0 0 24 24">
            <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
          </svg>
        );
      case 'instagram':
        return (
          <svg className="w-4 h-4 fill-current text-rose-400" viewBox="0 0 24 24">
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
          </svg>
        );
      case 'youtube':
        return (
          <svg className="w-4 h-4 fill-current text-red-500" viewBox="0 0 24 24">
            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
          </svg>
        );
      default:
        return <Sparkles className="w-4 h-4 text-red-400" />;
    }
  };

  return (
    <footer className="relative bg-[#050507] border-t border-red-950/40 pt-16 pb-12 overflow-hidden">
      {/* Top glowing crimson accent line */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-red-600/60 to-transparent" />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-white/5">
          
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 via-rose-600 to-black p-[1px] shadow-lg shadow-red-600/30">
                <div className="w-full h-full bg-[#0d0d12] rounded-[11px] flex items-center justify-center font-display font-black text-lg text-white">
                  <span className="text-red-500">T</span>
                  <span className="text-white">D</span>
                </div>
              </div>
              <div>
                <h3 className="font-display font-bold text-lg text-white tracking-wide">
                  THISHAN DINUJAYA
                </h3>
                <p className="text-xs font-mono text-red-400">
                  @ Web Developer & Video Editor
                </p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-gray-400 max-w-sm leading-relaxed">
              Crafting high-speed modern web applications and cinematic video edits with After Effects, Premiere Pro, React & Tailwind CSS.
            </p>

            {/* Vercel Hostable badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900 border border-white/10 text-[11px] text-gray-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Optimized for Vercel Fast Hosting</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-mono text-gray-400 uppercase tracking-wider mb-4">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-gray-400">
              <li>
                <button type="button" onClick={scrollToTop} className="hover:text-red-400 transition-colors">About & Profile</button>
              </li>
              <li>
                <button type="button" onClick={() => scrollToId('videos')} className="hover:text-red-400 transition-colors">Video Showcase (Anime & AE)</button>
              </li>
              <li>
                <button type="button" onClick={() => scrollToId('webdev')} className="hover:text-red-400 transition-colors">Web Development</button>
              </li>
              <li>
                <button type="button" onClick={() => scrollToId('skills')} className="hover:text-red-400 transition-colors">Skill Matrix</button>
              </li>
              <li>
                <button type="button" onClick={() => scrollToId('contact')} className="hover:text-red-400 transition-colors">Contact Channels</button>
              </li>
            </ul>
          </div>

          {/* Direct Social Channels */}
          <div>
            <h4 className="text-xs font-mono text-gray-400 uppercase tracking-wider mb-4">
              Connect Channels
            </h4>
            
            {/* Social Icons Grid */}
            <div className="flex flex-wrap gap-2 mb-4">
              {data.socialLinks.map((social, idx) => (
                <a
                  key={idx}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 border border-white/10 hover:border-red-500/50 flex items-center justify-center text-gray-300 hover:text-white hover:scale-110 transition-all duration-300 shadow-md group"
                  title={social.platform}
                >
                  {renderSocialIcon(social.platform)}
                </a>
              ))}
            </div>

            <p className="text-xs text-gray-400">
              Email: <span className="text-gray-200 font-mono">{data.email}</span>
            </p>
          </div>

        </div>

        {/* Bottom Copyright & Auto-Updating Year */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400">
          
          <div className="flex items-center gap-1.5 text-center sm:text-left">
            <span>© {currentYear}</span>
            <span className="font-semibold text-gray-200">Thishan Dinujaya</span>.
            <span className="hidden sm:inline">All rights reserved.</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1 text-[11px] text-gray-400">
              Made with <span className="text-red-500">❤️</span> & ❄️ Modern Dark Crimson UI
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-gray-400 hover:text-red-400 border border-white/10 transition-all shadow-md ml-2"
              title="Scroll to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </footer>
  );
};
