import React, { useState, useEffect } from 'react';
import { Sparkles } from 'lucide-react';

// Welcome gate popup: the OK tap is a real user gesture,
// so background music can autoplay WITH sound right after it.
export const WelcomeGate: React.FC = () => {
  const [open, setOpen] = useState(true);
  const [closing, setClosing] = useState(false);

  // Lock scroll while the gate is up
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open ]);

  if (!open) return null;

  const handleOk = () => {
    window.dispatchEvent(new CustomEvent('td:gate-open'));
    setClosing(true);
    setTimeout(() => setOpen(false), 350);
  };

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl transition-opacity duration-300 ${
        closing ? 'opacity-0' : 'opacity-100 animate-fadeIn'
      }`}
    >
      <div
        className={`relative w-full max-w-sm rounded-3xl bg-[#0c0c11] border border-red-500/40 shadow-2xl shadow-red-950/50 p-8 text-center transition-all duration-300 ${
          closing ? 'scale-95' : 'scale-100'
        }`}
      >
        {/* Logo mark */}
        <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-red-600 via-rose-600 to-black p-[1px] shadow-lg shadow-red-600/30 mb-5">
          <div className="w-full h-full bg-[#0d0d12] rounded-[15px] flex items-center justify-center font-display font-black text-2xl text-white">
            <span className="text-red-500">T</span>
            <span>D</span>
          </div>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/60 border border-red-500/30 text-red-400 text-[10px] font-mono uppercase tracking-widest mb-4">
          <Sparkles className="w-3 h-3" />
          <span>Welcome</span>
        </div>

        <h2 className="text-2xl font-black text-white font-display mb-2">Hi, 👋</h2>
        <p className="text-sm text-gray-300 leading-relaxed mb-6">
          please give me the ok button to view the portfolio 😉
        </p>

        <button
          type="button"
          autoFocus
          onClick={handleOk}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-base font-black tracking-wide shadow-xl shadow-red-600/40 transition-all hover:scale-[1.02] active:scale-95"
        >
          OK
        </button>

        <p className="text-[11px] text-gray-500 mt-4 flex items-center justify-center gap-1">
          🔊 sound on for the full vibe
        </p>
      </div>
    </div>
  );
};
