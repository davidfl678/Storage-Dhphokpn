import React, { useState } from 'react';
import { 
  Code, 
  Film, 
  Zap, 
  Terminal, 
  Palette, 
  Award 
} from 'lucide-react';
import { skillCategories } from '../data/portfolioData';

export const SkillsAndAboutSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'web' | 'video'>('all');

  return (
    <section id="skills" className="py-20 relative order-5 md:order-4">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/60 border border-red-500/30 text-red-400 text-xs font-mono uppercase tracking-wider mb-3">
              <Zap className="w-3.5 h-3.5" />
              <span>Skill Matrix & Expertise</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white font-display tracking-tight">
              Dual Craft: <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-red-600">Code & Motion</span>
            </h2>
            <p className="text-sm sm:text-base text-gray-400 mt-2 max-w-xl">
              Equipped with deep expertise in full-stack frontend development and professional VFX video editing tools.
            </p>
          </div>

          {/* Filter Tab Switcher */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-neutral-900/90 border border-white/10 self-start md:self-auto">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'all'
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/40'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              All Skills
            </button>
            <button
              onClick={() => setActiveTab('web')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'web'
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/40'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Code className="w-3.5 h-3.5 text-red-400" />
              <span>Web Dev</span>
            </button>
            <button
              onClick={() => setActiveTab('video')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'video'
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/40'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Film className="w-3.5 h-3.5 text-rose-400" />
              <span>Video / AE</span>
            </button>
          </div>
        </div>

        {/* Skill Category Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {skillCategories
            .filter((cat) => {
              if (activeTab === 'web') return cat.title.toLowerCase().includes('web');
              if (activeTab === 'video') return cat.title.toLowerCase().includes('video');
              return true;
            })
            .map((cat, idx) => {
              const isWeb = cat.title.toLowerCase().includes('web');
              return (
                <div
                  key={idx}
                  className="rounded-3xl bg-[#0c0c11]/90 border border-red-500/20 hover:border-red-500/40 p-6 sm:p-8 shadow-2xl backdrop-blur-xl transition-all duration-300"
                >
                  {/* Category Header */}
                  <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/5">
                    <div className="flex items-center gap-3.5">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg ${
                        isWeb ? 'bg-gradient-to-tr from-red-600 to-rose-600 shadow-red-600/30' : 'bg-gradient-to-tr from-rose-600 to-red-800 shadow-rose-600/30'
                      }`}>
                        {isWeb ? <Terminal className="w-6 h-6" /> : <Film className="w-6 h-6" />}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-white">{cat.title}</h3>
                        <p className="text-xs text-gray-400 mt-0.5">{cat.description}</p>
                      </div>
                    </div>
                  </div>

                  {/* Skills Progress List */}
                  <div className="space-y-4">
                    {cat.skills.map((skill, sIdx) => (
                      <div key={sIdx} className="group/item">
                        <div className="flex justify-between items-center text-xs mb-1.5">
                          <span className="font-semibold text-gray-200 group-hover/item:text-red-400 transition-colors flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                            {skill.name}
                          </span>
                          <div className="flex items-center gap-2">
                            {skill.badge && (
                              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-red-950/60 border border-red-500/30 text-red-300">
                                {skill.badge}
                              </span>
                            )}
                            <span className="font-mono text-gray-400 text-[11px]">{skill.level}%</span>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="h-2 w-full bg-neutral-900 rounded-full overflow-hidden p-[1px] border border-white/5">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-red-600 via-rose-500 to-red-400 transition-all duration-1000 ease-out shadow-sm shadow-red-500/50"
                            style={{ width: `${skill.level}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="glass-panel p-5 rounded-2xl border border-white/5 hover:border-red-500/30 transition-all flex flex-col justify-between">
            <div className="w-10 h-10 rounded-xl bg-red-950/70 border border-red-500/30 flex items-center justify-center text-red-400 mb-4">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white mb-1">Ultra Fast Web Apps</h4>
              <p className="text-xs text-gray-400">
                Responsive layouts built with Vite, Tailwind CSS, TypeScript & Next.js.
              </p>
            </div>
          </div>

          <div className="glass-panel p-5 rounded-2xl border border-white/5 hover:border-red-500/30 transition-all flex flex-col justify-between">
            <div className="w-10 h-10 rounded-xl bg-red-950/70 border border-red-500/30 flex items-center justify-center text-red-400 mb-4">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white mb-1">60 FPS Flow Edits</h4>
              <p className="text-xs text-gray-400">
                Smooth frame interpolation, motion blur, RSMB & tight sync to music beats.
              </p>
            </div>
          </div>

          <div className="glass-panel p-5 rounded-2xl border border-white/5 hover:border-red-500/30 transition-all flex flex-col justify-between">
            <div className="w-10 h-10 rounded-xl bg-red-950/70 border border-red-500/30 flex items-center justify-center text-red-400 mb-4">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white mb-1">Modern UI & VFX</h4>
              <p className="text-xs text-gray-400">
                Cyberpunk dark aesthetic, glassmorphism, glowing accents & custom animations.
              </p>
            </div>
          </div>

          <div className="glass-panel p-5 rounded-2xl border border-white/5 hover:border-red-500/30 transition-all flex flex-col justify-between">
            <div className="w-10 h-10 rounded-xl bg-red-950/70 border border-red-500/30 flex items-center justify-center text-red-400 mb-4">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white mb-1">Vercel Ready</h4>
              <p className="text-xs text-gray-400">
                Engineered for rapid CI/CD deployment on Vercel with zero latency.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
