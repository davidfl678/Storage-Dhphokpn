export interface ProfileData {
  name: string;
  headline: string;
  bio: string;
  age: number;
  birthday: string; // '2008-09-19'
  birthDateFormatted: string;
  location: string;
  status: string;
  profilePicUrl: string;
  backdropUrl: string;
  songUrl: string;
  songTitle: string;
  songArtist: string;
  email: string;
  whatsappNumbers: {
    label: string;
    number: string;
    description: string;
    isPrimary?: boolean;
  }[];
  telegram: {
    handle: string;
    url: string;
  };
  socialLinks: {
    platform: string;
    url: string;
    icon: string;
    color: string;
  }[];
}

export interface VideoItem {
  id: string;
  title: string;
  category: 'anime' | 'ae' | 'all';
  categoryLabel: string;
  videoUrl: string;
  posterUrl: string;
  description: string;
  tags: string[];
  software: string[];
  resolution?: string;
  fps?: string;
}

export interface WebProject {
  id: string;
  title: string;
  description: string;
  tags: string[];
  liveUrl?: string;
  githubUrl?: string;
  previewImage: string;
  featured?: boolean;
}

export interface SkillCategory {
  title: string;
  iconName: string;
  description: string;
  skills: {
    name: string;
    level: number;
    icon?: string;
    badge?: string;
  }[];
}
