import { ProfileData, VideoItem, WebProject, SkillCategory } from '../types';

export const initialProfileData: ProfileData = {
  name: "Thishan Dinujaya",
  headline: "Web Developer & Video Editor",
  bio: "Creative 18-year-old digital creator passionate about building lightning-fast modern web applications and crafting adrenaline-pumping video edits with Adobe After Effects & Premiere Pro.",
  age: 18,
  birthday: "2008-09-19",
  birthDateFormatted: "September 19, 2008 (2008/09/19)",
  location: "Sri Lanka 🇱🇰",
  status: "Available for Freelance & Projects",
  profilePicUrl: "https://spoo.me/Profile-pic-pt50",
  backdropUrl: "/images/backdrop.jpg",
  songUrl: "https://spoo.me/Backsong-pt09741",
  songTitle: "Atmospheric Cyber Beats",
  songArtist: "Thishan's Vibe Playlist",
  email: "thishan-D@proton.me",
  whatsappNumbers: [
    {
      label: "Primary WhatsApp",
      number: "+94 7X XXX XXX1",
      description: "Quick chat & project discussions",
      isPrimary: true
    },
    {
      label: "Business & Freelance",
      number: "+94 7X XXX XXX2",
      description: "Client inquiries & video commissions",
      isPrimary: false
    },
    {
      label: "Direct Line",
      number: "+94 7X XXX XXX3",
      description: "Urgent collaboration & tech support",
      isPrimary: false
    }
  ],
  telegram: {
    handle: "@thishan_dinujaya",
    url: "https://t.me/thishan_dinujaya"
  },
  socialLinks: [
    { platform: "Telegram", url: "https://t.me/thishan_dinujaya", icon: "Send", color: "#229ED9" },
    { platform: "Email", url: "mailto:thishan-D@proton.me", icon: "Mail", color: "#e11d48" },
    { platform: "WhatsApp", url: "https://wa.me/", icon: "MessageSquare", color: "#25D366" },
    { platform: "GitHub", url: "https://github.com/", icon: "Github", color: "#ffffff" },
    { platform: "Instagram", url: "https://instagram.com/", icon: "Instagram", color: "#E1306C" },
    { platform: "YouTube", url: "https://youtube.com/", icon: "Youtube", color: "#FF0000" }
  ]
};

export const videoItems: VideoItem[] = [
  {
    id: "anime-edit-1",
    title: "Anime Edit (AMV Flow & VFX)",
    category: "anime",
    categoryLabel: "Anime AMV Edit",
    videoUrl: "https://spoo.me/anime-edit01569",
    posterUrl: "/images/anime-edit-poster.jpg",
    description: "High-octane Anime AMV featuring seamless transitions, speed ramping, rhythmic beat-syncing, chromatic aberration, and particle effects.",
    tags: ["Anime AMV", "Flow Edit", "Beat Sync", "Color Grading", "60 FPS"],
    software: ["Adobe After Effects", "RSMB", "Sapphire Plugins", "Twixtor Pro"],
    resolution: "1080p Full HD",
    fps: "60 FPS"
  },
  {
    id: "ae-edit-1",
    title: "After Effects Motion & 3D Typography (AE)",
    category: "ae",
    categoryLabel: "After Effects AE Edit",
    videoUrl: "https://spoo.me/ae-edit48307",
    posterUrl: "/images/ae-edit-poster.jpg",
    description: "Futuristic 3D motion typography, neon HUD overlays, dynamic camera tracking, glitch transitions, and cinematic sound design built inside After Effects.",
    tags: ["Motion Graphics", "3D Typography", "HUD Overlay", "Sound Design", "VFX"],
    software: ["Adobe After Effects", "Element 3D", "Boris FX Mocha", "Premiere Pro"],
    resolution: "4K UHD Ready",
    fps: "60 FPS"
  }
];

export const skillCategories: SkillCategory[] = [
  {
    title: "Web Development",
    iconName: "Code",
    description: "Modern, responsive, and performance-optimized web architectures.",
    skills: [
      { name: "HTML5 & Modern CSS3", level: 95, badge: "Expert" },
      { name: "JavaScript / TypeScript", level: 90, badge: "Advanced" },
      { name: "React & Next.js", level: 88, badge: "Advanced" },
      { name: "Tailwind CSS & Styling", level: 95, badge: "Expert" },
      { name: "Responsive UI/UX Design", level: 92, badge: "Expert" },
      { name: "Git, GitHub & Vercel Deploy", level: 85, badge: "Skilled" },
      { name: "REST APIs & WebSockets", level: 82, badge: "Skilled" },
      { name: "Performance & SEO", level: 80, badge: "Skilled" }
    ]
  },
  {
    title: "Video Editing & VFX",
    iconName: "Film",
    description: "Visually arresting edits with rhythmic flow, custom VFX, and sound design.",
    skills: [
      { name: "Adobe After Effects (AE)", level: 95, badge: "Master" },
      { name: "Adobe Premiere Pro", level: 90, badge: "Advanced" },
      { name: "Anime AMV Editing & Flow", level: 98, badge: "Master" },
      { name: "Beat Sync & Speed Ramping", level: 96, badge: "Master" },
      { name: "Color Grading & LUTs", level: 88, badge: "Advanced" },
      { name: "Motion Graphics & 3D Typography", level: 90, badge: "Advanced" },
      { name: "Sapphire & Boris FX Plugins", level: 92, badge: "Advanced" },
      { name: "Sound Design & Audio Mastering", level: 85, badge: "Skilled" }
    ]
  }
];

export const webProjects: WebProject[] = [
  {
    id: "proj-1",
    title: "Cyberpunk Crimson Portfolio",
    description: "A dark neon cyberpunk interactive portfolio featuring dynamic particle snow effects, audio visualizer, and responsive video players.",
    tags: ["React", "TypeScript", "Tailwind CSS", "Canvas API", "Vercel"],
    previewImage: "/images/backdrop.jpg",
    featured: true
  },
  {
    id: "proj-2",
    title: "AMV & Video Creator Hub",
    description: "A high-performance video gallery showcasing 60FPS anime edits, after effects project files, preset downloads, and interactive media controls.",
    tags: ["Next.js", "Tailwind CSS", "Video.js", "Framer Motion"],
    previewImage: "/images/anime-edit-poster.jpg",
    featured: true
  },
  {
    id: "proj-3",
    title: "Neon Motion Design Showcase",
    description: "Interactive 3D WebGL typography viewer and motion graphics sandbox with real-time shader filters and audio reactive elements.",
    tags: ["React", "Three.js / WebGL", "Tailwind CSS", "SoundCloud API"],
    previewImage: "/images/ae-edit-poster.jpg",
    featured: true
  }
];
