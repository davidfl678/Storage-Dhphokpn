import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Menu, 
  X, 
  Send, 
  MessageSquare, 
  Code2, 
  Film, 
  User, 
  PhoneCall, 
  Settings2,
  ExternalLink
} from 'lucide-react';

interface NavbarProps {
  onOpenConfig?: () => void;
  telegramUrl: string;
  whatsappPrimary: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenConfig,
  telegramUrl,
  whatsappPrimary
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about', icon: User },
    { name: 'Video Edits', href: '#videos', icon: Film, badge: 'AE & AMV' },
    { name: 'Web Dev', href: '#webdev', icon: Code2 },
    { name: 'Skills', href: '#skills', icon: Sparkles },
    { name: 'Contact', href: '#contact', icon: PhoneCall },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'py-3 bg-[#09090c]/90 backdrop-blur-md border-b border-red-900/30 shadow-lg shadow-black/60' 
        : 'py-5 bg-transparent'
    }`}>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between">
        {/* Brand Logo */}
        <a href="#" className="flex items-center gap-3 group">
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 via-rose-600 to-black p-[1px] shadow-lg shadow-red-600/20 group-hover:shadow-red-600/50 transition-all duration-300">
            <div className="w-full h-full bg-[#0d0d12] rounded-[11px] flex items-center justify-center font-display font-black text-lg text-white">
              <span className="text-red-500 group-hover:text-red-400">T</span>
              <span className="text-white">D</span>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-base tracking-wider text-white group-hover:text-red-400 transition-colors flex items-center gap-1.5">
              THISHAN DINUJAYA
            </span>
            <span className="text-[10px] font-mono tracking-widest text-red-400 uppercase">
              DEV • VIDEO EDITOR
            </span>
          </div>
        </a>

        {/* Desktop Nav Items */}
        <nav className="hidden md:flex items-center gap-1 bg-black/40 border border-white/5 rounded-full px-4 py-1.5 backdrop-blur-lg">
          {navLinks.map((link) => {
            const IconComponent = link.icon;
            return (
              <a
                key={link.name}
                href={link.href}
                className="relative px-3.5 py-1.5 text-xs font-medium text-gray-300 hover:text-white rounded-full transition-all hover:bg-white/5 flex items-center gap-1.5 group"
              >
                <IconComponent className="w-3.5 h-3.5 text-red-500/80 group-hover:text-red-400 transition-colors" />
                <span>{link.name}</span>
                {link.badge && (
                  <span className="text-[9px] bg-red-600/30 text-red-300 border border-red-500/30 px-1 rounded">
                    {link.badge}
                  </span>
                )}
              </a>
            );
          })}
        </nav>

        {/* Right Action Buttons */}
        <div className="hidden sm:flex items-center gap-2.5">
          {/* Quick config modal trigger */}
          {onOpenConfig && (
            <button
              onClick={onOpenConfig}
              className="p-2 rounded-xl bg-neutral-900/80 hover:bg-neutral-800 text-gray-400 hover:text-red-400 border border-white/5 hover:border-red-500/30 transition-all"
              title="Edit Profile Data & Links"
            >
              <Settings2 className="w-4 h-4" />
            </button>
          )}

          {/* Telegram Quick Link */}
          <a
            href={telegramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900/80 hover:bg-[#229ED9]/20 text-gray-300 hover:text-[#229ED9] border border-white/5 hover:border-[#229ED9]/40 text-xs font-medium transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Telegram</span>
          </a>

          {/* Contact / Hire CTA */}
          <a
            href="#contact"
            className="flex items-center gap-2 px-4 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-semibold shadow-lg shadow-red-600/30 hover:shadow-red-600/50 transition-all active:scale-95"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Let's Talk</span>
          </a>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex md:hidden items-center gap-2">
          {onOpenConfig && (
            <button
              onClick={onOpenConfig}
              className="p-2 rounded-lg bg-neutral-900 text-gray-400 hover:text-red-400 border border-white/5"
            >
              <Settings2 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-neutral-900 text-gray-300 hover:text-white border border-white/5"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden glass-panel-red border-t border-b border-red-500/20 px-6 py-5 mt-2 animate-fadeIn flex flex-col gap-3">
          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 p-2.5 rounded-xl bg-black/40 border border-white/5 text-xs text-gray-200 hover:text-red-400 hover:border-red-500/40 transition-colors"
                >
                  <Icon className="w-4 h-4 text-red-500" />
                  <span>{link.name}</span>
                </a>
              );
            })}
          </div>

          <div className="pt-2 border-t border-red-500/20 flex gap-2">
            <a
              href={`https://wa.me/${whatsappPrimary.replace(/\D/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-2 p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 text-xs font-medium"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
            <a
              href={telegramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-2 p-2 rounded-xl bg-sky-950/40 border border-sky-500/30 text-sky-400 text-xs font-medium"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Telegram</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
