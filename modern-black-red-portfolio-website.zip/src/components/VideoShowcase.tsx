import React, { useState, useRef } from 'react';
import { 
  Play, 
  Maximize2, 
  ExternalLink, 
  Film, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Check, 
  Copy, 
  Clapperboard, 
  Flame
} from 'lucide-react';
import { VideoItem } from '../types';

interface VideoShowcaseProps {
  videos: VideoItem[];
}

export const VideoShowcase: React.FC<VideoShowcaseProps> = ({ videos }) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'anime' | 'ae'>('all');
  const [playingVideoId, setPlayingVideoId] = useState<string | null>(null);
  const [theaterVideo, setTheaterVideo] = useState<VideoItem | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [mutedStates, setMutedStates] = useState<Record<string, boolean>>({});

  const filteredVideos = activeCategory === 'all' 
    ? videos 
    : videos.filter((v) => v.category === activeCategory);

  const toggleMute = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setMutedStates((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleCopyLink = (video: VideoItem, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(video.videoUrl);
    setCopiedId(video.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <section id="videos" className="py-20 relative">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/60 border border-red-500/30 text-red-400 text-xs font-mono uppercase tracking-wider mb-3">
              <Film className="w-3.5 h-3.5" />
              <span>Video Portfolio • 60 FPS Creations</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white font-display tracking-tight">
              Featured <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-red-600">Video Edits</span>
            </h2>
            <p className="text-sm sm:text-base text-gray-400 mt-2 max-w-xl">
              High-energy anime flow edits, synchronized transitions, and futuristic After Effects motion design.
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-neutral-900/90 border border-white/10 self-start md:self-auto">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeCategory === 'all'
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/40'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              All Edits ({videos.length})
            </button>
            <button
              onClick={() => setActiveCategory('anime')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeCategory === 'anime'
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/40'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-red-400" />
              <span>Anime Edit</span>
            </button>
            <button
              onClick={() => setActiveCategory('ae')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeCategory === 'ae'
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/40'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-rose-400" />
              <span>After Effects (AE)</span>
            </button>
          </div>
        </div>

        {/* Video Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredVideos.map((video) => {
            const isPlaying = playingVideoId === video.id;
            const isMuted = mutedStates[video.id] ?? true;

            return (
              <div
                key={video.id}
                className="group rounded-3xl bg-[#0c0c11]/90 border border-red-500/20 hover:border-red-500/50 shadow-2xl overflow-hidden backdrop-blur-xl transition-all duration-300 hover:shadow-red-950/40 flex flex-col"
              >
                {/* Video / Player Container */}
                <div className="relative aspect-video w-full bg-black overflow-hidden select-none">
                  <VideoPlayerCard
                    video={video}
                    isPlaying={isPlaying}
                    isMuted={isMuted}
                    onPlayToggle={() => {
                      setPlayingVideoId(isPlaying ? null : video.id);
                    }}
                  />

                  {/* Top Badges Overlay */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-20">
                    <span className="px-3 py-1 rounded-full bg-black/80 border border-red-500/40 text-[11px] font-bold text-red-400 backdrop-blur-md flex items-center gap-1.5 shadow-lg">
                      {video.category === 'anime' ? (
                        <Flame className="w-3 h-3 text-red-500" />
                      ) : (
                        <Clapperboard className="w-3 h-3 text-rose-400" />
                      )}
                      {video.categoryLabel}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {video.fps && (
                        <span className="px-2 py-0.5 rounded-md bg-red-950/80 border border-red-500/30 text-[10px] font-mono text-red-300 backdrop-blur-md">
                          {video.fps}
                        </span>
                      )}
                      {video.resolution && (
                        <span className="px-2 py-0.5 rounded-md bg-black/80 border border-white/20 text-[10px] font-mono text-gray-200 backdrop-blur-md">
                          {video.resolution}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Quick Control Overlays bottom */}
                  <div className="absolute bottom-3 right-3 flex items-center gap-2 z-20">
                    <button
                      onClick={(e) => toggleMute(video.id, e)}
                      className="p-2 rounded-xl bg-black/70 hover:bg-black/90 text-white border border-white/20 backdrop-blur-md transition-colors shadow-lg"
                      title={isMuted ? "Unmute" : "Mute"}
                    >
                      {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-white" />}
                    </button>
                    <button
                      onClick={() => setTheaterVideo(video)}
                      className="p-2 rounded-xl bg-black/70 hover:bg-black/90 text-white border border-white/20 backdrop-blur-md transition-colors shadow-lg"
                      title="Open Theater Fullscreen"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Video Info Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white group-hover:text-red-400 transition-colors mb-2">
                      {video.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-400 leading-relaxed mb-4">
                      {video.description}
                    </p>

                    {/* Software Used Tags */}
                    <div className="mb-4">
                      <span className="text-[11px] font-mono text-gray-400 uppercase tracking-wider block mb-2">
                        Software & Plugins:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {video.software.map((sw, idx) => (
                          <span
                            key={idx}
                            className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-white/5 text-[11px] text-gray-300 font-medium"
                          >
                            {sw}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Footer Actions */}
                  <div className="pt-4 border-t border-white/5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => handleCopyLink(video, e)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-white/10 text-xs text-gray-300 hover:text-white transition-all"
                        title="Copy Video Link"
                      >
                        {copiedId === video.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Link Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-gray-400" />
                            <span>Copy Link</span>
                          </>
                        )}
                      </button>

                      <a
                        href={video.videoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-white/10 text-xs text-gray-300 hover:text-white transition-all"
                        title="Open direct video link in new tab"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Direct Link</span>
                      </a>
                    </div>

                    <button
                      onClick={() => setTheaterVideo(video)}
                      className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 border border-red-500/40 text-xs font-bold text-red-300 hover:text-white transition-all shadow-md"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Watch Full</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Video Commission & Custom Edits Callout */}
        <div className="mt-12 rounded-3xl glass-panel-red p-6 sm:p-8 border border-red-500/30 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-red-600 to-rose-600 flex items-center justify-center text-white shadow-xl shadow-red-600/40 flex-shrink-0">
              <Clapperboard className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                Want a Custom AMV or After Effects Motion Graphic?
              </h3>
              <p className="text-xs sm:text-sm text-gray-300 mt-0.5">
                Available for YouTube Intros, TikTok edits, Anime Flow AMVs, 3D Typography, and visualizer commissions.
              </p>
            </div>
          </div>
          <a
            href="#contact"
            className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs sm:text-sm font-bold shadow-xl shadow-red-600/40 transition-all hover:scale-105 active:scale-95 whitespace-nowrap"
          >
            <span>Order Video Edit</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>

      </div>

      {/* Fullscreen Theater Modal */}
      {theaterVideo && (
        <div
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6 animate-fadeIn"
          onClick={() => setTheaterVideo(null)}
        >
          <div
            className="relative w-full max-w-5xl rounded-3xl bg-[#09090c] border border-red-500/40 shadow-2xl overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 sm:p-5 flex items-center justify-between border-b border-red-500/20 bg-black/50">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                <h3 className="text-base sm:text-lg font-bold text-white truncate max-w-md">
                  {theaterVideo.title}
                </h3>
              </div>
              <button
                onClick={() => setTheaterVideo(null)}
                className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-red-950 text-gray-300 hover:text-white border border-white/10 text-xs font-semibold transition-colors"
              >
                Close ✕
              </button>
            </div>

            {/* Main Video in Theater View */}
            <div className="relative aspect-video w-full bg-black">
              <VideoPlayerCard
                video={theaterVideo}
                isPlaying={true}
                isMuted={false}
                autoPlay={true}
                controls={true}
              />
            </div>

            {/* Footer in Theater View */}
            <div className="p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 bg-black/60 border-t border-white/5">
              <div className="flex flex-wrap gap-2">
                {theaterVideo.tags.map((t, idx) => (
                  <span key={idx} className="px-2.5 py-1 rounded-lg bg-red-950/60 border border-red-500/30 text-red-300 text-xs">
                    #{t}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={theaterVideo.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-lg"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open Video URL</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

// Sub-component for individual video player handling with HTML5 video and iframe/redirect fallback
interface VideoPlayerCardProps {
  video: VideoItem;
  isPlaying?: boolean;
  isMuted?: boolean;
  autoPlay?: boolean;
  controls?: boolean;
  onPlayToggle?: () => void;
}

const VideoPlayerCard: React.FC<VideoPlayerCardProps> = ({
  video,
  isPlaying = false,
  isMuted = true,
  autoPlay = false,
  controls = false,
  onPlayToggle
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  // Play/pause sync
  React.useEffect(() => {
    if (!videoRef.current) return;
    if (isPlaying || autoPlay) {
      videoRef.current.play().catch(() => {
        // Autoplay may be restricted or url is redirect
      });
    } else {
      videoRef.current.pause();
    }
  }, [isPlaying, autoPlay]);

  return (
    <div className="relative w-full h-full bg-neutral-950 flex items-center justify-center">
      {/* Background Poster Image */}
      <img
        src={video.posterUrl}
        alt={video.title}
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
          isPlaying && isLoaded && !hasError ? 'opacity-0 pointer-events-none' : 'opacity-80'
        }`}
      />

      {/* HTML5 Video Element */}
      <video
        ref={videoRef}
        src={video.videoUrl}
        poster={video.posterUrl}
        muted={isMuted}
        loop
        playsInline
        controls={controls}
        onLoadedData={() => setIsLoaded(true)}
        onError={() => setHasError(true)}
        className={`w-full h-full object-cover ${
          isPlaying ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* Dark tint gradient overlay when paused */}
      {!isPlaying && (
        <div 
          onClick={onPlayToggle}
          className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex items-center justify-center cursor-pointer group/overlay"
        >
          {/* Animated Big Play Button */}
          <div className="w-16 h-16 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-2xl shadow-red-600/70 border-2 border-white/20 group-hover/overlay:scale-110 group-hover/overlay:bg-red-500 transition-all duration-300">
            <Play className="w-7 h-7 fill-current ml-1" />
          </div>
        </div>
      )}

      {/* Fallback Notice if Video URL is redirected or blocked */}
      {hasError && isPlaying && (
        <div className="absolute inset-0 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-10">
          <Film className="w-10 h-10 text-red-500 mb-2" />
          <p className="text-sm font-semibold text-white mb-1">Direct Video Preview</p>
          <p className="text-xs text-gray-400 mb-4 max-w-xs">
            This video is hosted at <span className="text-red-400">{video.videoUrl}</span>
          </p>
          <div className="flex items-center gap-2">
            <a
              href={video.videoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-lg"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Watch on Link</span>
            </a>
            <button
              onClick={() => {
                setHasError(false);
                if (videoRef.current) {
                  videoRef.current.load();
                }
              }}
              className="flex items-center gap-1 px-3 py-2 rounded-xl bg-neutral-800 text-gray-300 text-xs hover:bg-neutral-700"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
