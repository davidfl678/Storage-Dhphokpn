import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Volume2, VolumeX, Music, Disc3, Radio } from 'lucide-react';

interface AudioPlayerProps {
  songUrl: string;
  songTitle?: string;
  songArtist?: string;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  songUrl,
  songTitle = "Cyber Vibe Soundtrack",
  songArtist = "Thishan's Playlist"
}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.6);
  const [hasInteracted, setHasInteracted] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [loadError, setLoadError] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);

  // Reliable backup synthwave ambient track in case the short link has temporary network/cors issues
  const backupAudioUrl = "https://cdn.freesound.org/previews/530/530415_11861866-lq.mp3";
  const [currentSrc, setCurrentSrc] = useState<string>(songUrl);

  useEffect(() => {
    setCurrentSrc(songUrl);
    setLoadError(false);
  }, [songUrl]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.volume = isMuted ? 0 : volume;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration || 0);
    const handleEnded = () => {
      // Loop audio
      audio.currentTime = 0;
      audio.play().catch(() => {});
    };

    const handleError = () => {
      console.warn("Audio load error on primary URL, switching to backup stream.");
      if (currentSrc !== backupAudioUrl) {
        setCurrentSrc(backupAudioUrl);
        setLoadError(true);
      }
    };

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('loadedmetadata', updateDuration);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('loadedmetadata', updateDuration);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [volume, isMuted, currentSrc]);

  // Handle first user interaction anywhere on the page to allow autoplay if desired
  useEffect(() => {
    const handleFirstGesture = () => {
      if (!hasInteracted) {
        setHasInteracted(true);
      }
    };

    window.addEventListener('click', handleFirstGesture, { once: true });
    window.addEventListener('keydown', handleFirstGesture, { once: true });

    return () => {
      window.removeEventListener('click', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
    };
  }, [hasInteracted]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => {
        setIsPlaying(true);
        setHasInteracted(true);
      }).catch((err) => {
        console.error("Audio playback error:", err);
      });
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (val === 0) {
      setIsMuted(true);
    } else if (isMuted) {
      setIsMuted(false);
    }
    if (audioRef.current) {
      audioRef.current.volume = val;
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00";
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <>
      <audio
        ref={audioRef}
        src={currentSrc}
        preload="metadata"
        loop
      />

      {/* Floating Audio Player Widget at bottom-left */}
      <div className="fixed bottom-6 left-5 z-40 flex items-center gap-2">
        <div className={`glass-panel-red rounded-full transition-all duration-300 shadow-2xl border border-red-500/30 flex items-center p-1.5 ${
          isExpanded ? 'px-4 py-2 bg-black/90' : 'bg-black/75'
        }`}>
          {/* Main Play/Pause Button */}
          <button
            onClick={togglePlay}
            className={`relative flex items-center justify-center w-10 h-10 rounded-full transition-all duration-300 ${
              isPlaying
                ? 'bg-gradient-to-tr from-red-600 to-rose-500 text-white shadow-lg shadow-red-600/50 scale-105'
                : 'bg-neutral-900 text-red-400 hover:text-white hover:bg-red-950/80 border border-red-500/30'
            }`}
            title={isPlaying ? "Pause Background Music" : "Play Background Music"}
            aria-label={isPlaying ? "Pause music" : "Play music"}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}

            {/* Glowing Pulse Ring when Playing */}
            {isPlaying && (
              <span className="absolute inset-0 rounded-full bg-red-500 animate-ping opacity-25" />
            )}
          </button>

          {/* Equalizer Wave / Info */}
          <div
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-3 px-3 cursor-pointer select-none"
          >
            {/* Spinning Vinyl Disk */}
            <div className="relative flex items-center justify-center">
              <Disc3 className={`w-5 h-5 text-red-400 ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '3s' }} />
            </div>

            {/* Title / Equalizer */}
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-gray-200 tracking-wide max-w-[120px] sm:max-w-[160px] truncate">
                  {songTitle}
                </span>
                {loadError && (
                  <span className="text-[9px] bg-red-900/60 text-red-300 px-1.5 py-0.5 rounded">Fallback</span>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                {isPlaying ? (
                  <div className="flex items-end gap-0.5 h-3">
                    <span className="w-0.5 bg-red-400 rounded-full equalizer-bar-1" />
                    <span className="w-0.5 bg-red-500 rounded-full equalizer-bar-2" />
                    <span className="w-0.5 bg-rose-400 rounded-full equalizer-bar-3" />
                    <span className="w-0.5 bg-red-400 rounded-full equalizer-bar-4" />
                  </div>
                ) : (
                  <span className="text-[10px] text-gray-400 flex items-center gap-1">
                    <Music className="w-2.5 h-2.5 text-red-400/80" /> BGM Paused
                  </span>
                )}
                <span className="text-[10px] text-gray-400">
                  {isPlaying ? `${formatTime(currentTime)} / ${formatTime(duration)}` : songArtist}
                </span>
              </div>
            </div>
          </div>

          {/* Volume Controls & Expand */}
          <div className="flex items-center gap-2 pr-1 border-l border-red-500/20 pl-2">
            <button
              onClick={toggleMute}
              className="text-gray-400 hover:text-red-400 p-1 transition-colors"
              title={isMuted ? "Unmute" : "Mute"}
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4 text-red-400" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>

            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="w-14 sm:w-20 h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-500 hidden sm:block"
              title="Volume"
            />
          </div>
        </div>

        {/* First Time Play Invitation Toast */}
        {!hasInteracted && !isPlaying && (
          <div
            onClick={togglePlay}
            className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-950/90 border border-red-500/40 text-xs text-red-200 cursor-pointer shadow-lg animate-bounce hover:bg-red-900 transition-colors"
          >
            <Radio className="w-3.5 h-3.5 text-red-400 animate-pulse" />
            <span>Play background song 🎶</span>
          </div>
        )}
      </div>
    </>
  );
};
