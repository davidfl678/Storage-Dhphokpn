import React, { useState } from 'react';
import { 
  Code2, 
  ExternalLink, 
  Terminal, 
  Sparkles,
  Layers,
  Monitor
} from 'lucide-react';
import { webProjects } from '../data/portfolioData';
import { WebProject } from '../types';

export const WebProjectsSection: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<WebProject | null>(null);

  return (
    <section id="webdev" className="py-20 relative bg-[#060608]/60">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/60 border border-red-500/30 text-red-400 text-xs font-mono uppercase tracking-wider mb-3">
              <Code2 className="w-3.5 h-3.5" />
              <span>Full-Stack & Frontend Work</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white font-display tracking-tight">
              Web Development <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-red-600">Creations</span>
            </h2>
            <p className="text-sm sm:text-base text-gray-400 mt-2 max-w-xl">
              High-performance web apps with cyber crimson design systems, ultra-fast Vite builds, and modern React architectures.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-gray-400 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 border border-white/5">
              <Monitor className="w-3.5 h-3.5 text-red-400" /> Vercel Optimized
            </span>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {webProjects.map((project) => (
            <div
              key={project.id}
              className="group rounded-3xl bg-[#0c0c11]/90 border border-red-500/20 hover:border-red-500/50 overflow-hidden shadow-2xl backdrop-blur-xl transition-all duration-300 hover:shadow-red-950/40 flex flex-col justify-between"
            >
              <div>
                {/* Preview Image with Red Gradient Overlay */}
                <div className="relative h-48 w-full overflow-hidden bg-black">
                  <img
                    src={project.previewImage}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c11] via-transparent to-transparent" />
                  
                  {project.featured && (
                    <div className="absolute top-3 right-3 px-2.5 py-0.5 rounded-full bg-red-600/90 text-white text-[10px] font-bold font-mono tracking-wider shadow-lg flex items-center gap-1">
                      <Sparkles className="w-2.5 h-2.5" /> FEATURED
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-lg font-bold text-white group-hover:text-red-400 transition-colors mb-2">
                    {project.title}
                  </h3>
                  <p className="text-xs text-gray-400 leading-relaxed mb-4">
                    {project.description}
                  </p>

                  {/* Tech Tags */}
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {project.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-md bg-neutral-900 border border-white/5 text-[10px] font-mono text-gray-300"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions Bottom */}
              <div className="p-6 pt-0 border-t border-white/5 mt-2 flex items-center justify-between">
                <button
                  onClick={() => setSelectedProject(project)}
                  className="flex items-center gap-1.5 text-xs text-gray-300 hover:text-white transition-colors"
                >
                  <Layers className="w-3.5 h-3.5 text-red-400" />
                  <span>Inspect Tech</span>
                </button>

                <a
                  href="#contact"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/30 text-xs font-semibold transition-all"
                >
                  <span>Build Similar</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Tech Inspect Modal */}
      {selectedProject && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setSelectedProject(null)}
        >
          <div
            className="relative max-w-lg w-full rounded-3xl bg-[#0c0c11] border border-red-500/40 p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-red-500/20 mb-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-red-500" />
                <h3 className="text-lg font-bold text-white">{selectedProject.title}</h3>
              </div>
              <button
                onClick={() => setSelectedProject(null)}
                className="text-gray-400 hover:text-white text-xs px-2.5 py-1 rounded-lg bg-neutral-900"
              >
                ✕
              </button>
            </div>

            <p className="text-xs sm:text-sm text-gray-300 mb-4 leading-relaxed">
              {selectedProject.description}
            </p>

            <div className="mb-4">
              <span className="text-xs font-mono text-gray-400 uppercase tracking-wider block mb-2">
                Stack Architecture:
              </span>
              <div className="flex flex-wrap gap-2">
                {selectedProject.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-xl bg-red-950/60 border border-red-500/30 text-xs text-red-300 font-mono"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-white/5 flex justify-end gap-2">
              <button
                onClick={() => setSelectedProject(null)}
                className="px-4 py-2 rounded-xl bg-neutral-900 text-gray-300 text-xs hover:text-white"
              >
                Close
              </button>
              <a
                href="#contact"
                onClick={() => setSelectedProject(null)}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all"
              >
                Request Custom Web App
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
